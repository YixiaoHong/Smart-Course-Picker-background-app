import io

import boto3
import numpy
import matplotlib.pyplot as plt

from dynamodb.db import get_hot_course_data
from s3.S3Helper import store_file

hot_course_img_name = "pop_course.png"

def get_hot_courses():
    return get_hot_course_data()

def make_dict_for_draw(courses):
    # sorted(courses, key=lambda x: x.count, reverse=True)
    dict = {}
    for c in courses:
        # sum(p.code == "F" for p in courses)
        if c.code in dict:
            dict[c.code] = dict[c.code] + 1
        else:
            dict[c.code] = 1 # start with 1
    return dict

def draw(dictionary):
    y_pos = numpy.arange(len(dictionary))
    plt.figure(figsize=(10, 6))
    plt.barh(y_pos, dictionary.values())
    plt.gca().invert_yaxis()
    plt.yticks(y_pos, dictionary.keys())
    plt.ylim(len(dictionary), -1)
    index = 0
    for a in dictionary:
        plt.annotate(dictionary[a], xy=(dictionary[a] + 0.2, y_pos[index] + 0.3), fontsize=15)
        index += 1
    plt.xlabel("Searched Frequency", fontsize=15)
    plt.ylabel("Course Code", fontsize=15)
    plt.rc('xtick', labelsize=20)
    plt.rc('ytick', labelsize=20)
    plt.title("Most Popular Courses Searched in the Past 48 hours", fontsize=25, color='b')

    img_data = io.BytesIO()
    plt.savefig(img_data, format='png')
    img_data.seek(0)
    return img_data


def run(event, context):
    '''
    '''
    courses = get_hot_courses()
    dict = make_dict_for_draw(courses)
    print(dict)
    img = draw(dict)
    store_file(hot_course_img_name, img)
    return "True"
