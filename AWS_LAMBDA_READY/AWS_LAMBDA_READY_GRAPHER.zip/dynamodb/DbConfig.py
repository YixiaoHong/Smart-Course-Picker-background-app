#Data Base Configuration

'''
This file includes a dictionary named db_config which has 4 keys: user, password, host and database which contains the
information of database IP address, default login database, database login username and password, all values in Strings.
'''

db_config = {'user': 'eceme',
             'password': 'password',
             'host': 'ece1779database.cvba4gkntcs6.us-east-1.rds.amazonaws.com',
             'database': 'ece1779'}
